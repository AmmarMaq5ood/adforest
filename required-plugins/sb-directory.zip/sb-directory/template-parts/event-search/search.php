<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
defined('ABSPATH') || exit;
get_header();
?>
<?php wc_get_template2('event-search/search-form.php');  ?>      
  <?php       
get_footer();

